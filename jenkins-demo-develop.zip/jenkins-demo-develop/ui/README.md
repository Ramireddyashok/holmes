# ui

## Fetch dependencies
```
yarn install
```

## Run Webpack
```
yarn run build
```

## Start http-server
```
yarn start
```
