declare module '*.html' {
    var _: string;
    export default  _;
}
