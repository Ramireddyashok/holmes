using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace App.Api.Models
{
	public class AppIdentityUser : IdentityUser
	{
	}
}
